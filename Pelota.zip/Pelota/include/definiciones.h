/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   definiciones.h
 * Author: alejandro
 *
 * Created on 2 de mayo de 2019, 16:29
 */

#ifndef DEFINICIONES_H
#define DEFINICIONES_H

const int MIN_X = 800;
const int MIN_Y = 600;
const int MAX_VEL = 50;
const int RADIO = 80;
const int UMBRAL = 2*RADIO;

#endif /* DEFINICIONES_H */

